/* $Id: xgpio.h,v 1.6 2004/02/24 23:19:42 moleres Exp $ */
/******************************************************************************
*
*       XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
*       AS A COURTESY TO YOU, SOLELY FOR USE IN DEVELOPING PROGRAMS AND
*       SOLUTIONS FOR XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE,
*       OR INFORMATION AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE,
*       APPLICATION OR STANDARD, XILINX IS MAKING NO REPRESENTATION
*       THAT THIS IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
*       AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
*       FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
*       WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
*       IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
*       REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
*       INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
*       FOR A PARTICULAR PURPOSE.
*
*       (c) Copyright 2002 Xilinx Inc.
*       All rights reserved.
*
******************************************************************************/
/*****************************************************************************/
/**
* @file xgpio.h
*
* This file contains the software API definition of the Xilinx General Purpose
* I/O (XGpio) component.
*
* The Xilinx GPIO controller is a soft IP core designed for  Xilinx FPGAs and
* contains the following general features:
*   - Support for 8, 16, or 32 I/O discretes
*   - Each of the discretes can be configured for input or output.
*
* @note
*
* This driver does not support the second channel of the dual channel gpio
* cores, nor does it support interrupts for those gpio cores that include
* interrupts.
*
* This API utilizes 32 bit I/O to the GPIO registers. With 16 and 8 bit GPIO
* components, the unused bits from registers are read as zero and written as
* don't cares.
*
* <pre>
* MODIFICATION HISTORY:
*
* Ver   Who  Date     Changes
* ----- ---- -------- --------------------------------------------------------
* 1.00a rmm  03/13/02 First release
* 1.00a rpm  02/24/04 Added notes indicating lack of interrupt and dual channel
*			 		  support.
* </pre>
*****************************************************************************/

#ifndef XGPIO_H  /* prevent circular inclusions */
#define XGPIO_H  /* by using protection macros */

/***************************** Include Files ********************************/

#include "xbasic_types.h"
#include "xstatus.h"
#include "xgpio_l.h"

/************************** Constant Definitions ****************************/

/**************************** Type Definitions ******************************/

/*
 * This typedef contains configuration information for the device.
 */
typedef struct
{
    Xuint16 DeviceId;      /* Unique ID  of device */
    Xuint32 BaseAddress;   /* Device base address */
} XGpio_Config;

/**
 * The XGpio driver instance data. The user is required to allocate a
 * variable of this type for every GPIO device in the system. A pointer
 * to a variable of this type is then passed to the driver API functions.
 */
typedef struct
{
    Xuint32 BaseAddress;   /* Device base address */
    Xuint32 IsReady;       /* Device is initialized and ready */
} XGpio;


/***************** Macros (Inline Functions) Definitions ********************/


/************************** Function Prototypes *****************************/

/*
 * API Basic functions implemented in xgpio.c
 */
XStatus XGpio_Initialize(XGpio *InstancePtr, Xuint16 DeviceId);
void    XGpio_SetDataDirection(XGpio *InstancePtr, Xuint32 DirectionMask);
Xuint32 XGpio_DiscreteRead(XGpio *InstancePtr);
void    XGpio_DiscreteWrite(XGpio *InstancePtr, Xuint32 Mask);

XGpio_Config *XGpio_LookupConfig(Xuint16 DeviceId);

/*
 * API Functions implemented in xgpio_extra.c
 */
void    XGpio_DiscreteSet(XGpio *InstancePtr, Xuint32 Mask);
void    XGpio_DiscreteClear(XGpio *InstancePtr, Xuint32 Mask);

/*
 * API Functions implemented in xgpio_selftest.c
 */
XStatus XGpio_SelfTest(XGpio *InstancePtr);
#endif            /* end of protection macro */
