/* $Id: xgpio_l.h,v 1.3 2004/02/24 23:19:42 moleres Exp $ */
/******************************************************************************
*
*       XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
*       AS A COURTESY TO YOU, SOLELY FOR USE IN DEVELOPING PROGRAMS AND
*       SOLUTIONS FOR XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE,
*       OR INFORMATION AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE,
*       APPLICATION OR STANDARD, XILINX IS MAKING NO REPRESENTATION
*       THAT THIS IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
*       AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
*       FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
*       WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
*       IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
*       REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
*       INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
*       FOR A PARTICULAR PURPOSE.
*
*       (c) Copyright 2002 Xilinx Inc.
*       All rights reserved.
*
******************************************************************************/
/*****************************************************************************/
/**
*
* @file xgpio_l.h
*
* This header file contains identifiers and low-level driver functions (or
* macros) that can be used to access the device.  The user should refer to the
* hardware device specification for more details of the device operation.
* High-level driver functions are defined in xgpio.h.
*
* @note
*
* This driver does not support the second channel of the dual channel gpio
* cores, nor does it support interrupts for those gpio cores that include
* interrupts.
*
* <pre>
* MODIFICATION HISTORY:
*
* Ver   Who  Date     Changes
* ----- ---- -------- -----------------------------------------------
* 1.00a jhl  04/24/02 First release
* 1.00a rpm  02/24/04 Added notes indicating lack of interrupt and dual channel
*			 		  support.
* </pre>
*
******************************************************************************/

#ifndef XGPIO_L_H /* prevent circular inclusions */
#define XGPIO_L_H /* by using protection macros */

/***************************** Include Files *********************************/

#include "xbasic_types.h"
#include "xio.h"

/************************** Constant Definitions *****************************/

/** @name Registers
 *
 * Register offsets for this device. This device does not utilize IPIF registers.
 * @{
 */
/**
 * - XGPIO_DATA_OFFSET    Data register
 * - XGPIO_TRI_OFFSET     Three state register (sets input/output direction)
 *                        0 configures pin for output and 1 for input.
 */
#define XGPIO_DATA_OFFSET  0x00000000
#define XGPIO_TRI_OFFSET   0x00000004
/* @} */

/**************************** Type Definitions *******************************/


/***************** Macros (Inline Functions) Definitions *********************/


/*****************************************************************************
*
* Low-level driver macros.  The list below provides signatures to help the
* user use the macros.
*
* Xuint32 XGpio_mReadReg(Xuint32 BaseAddress, int RegOffset, Xuint32 Data)
* void XGpio_mWriteReg(Xuint32 BaseAddress, int RegOffset, Xuint32 Data)
*
* void XGpio_mSetDataDirection(Xuint32 BaseAddress, Xuint32 DirectionMask)
*
* Xuint32 XGpio_mGetDataReg(Xuint32 BaseAddress)
* void XGpio_mSetDataReg(Xuint32 BaseAddress, Xuint32 Mask)
*
*****************************************************************************/

/****************************************************************************/
/**
 *
 * Write a value to a GPIO register. A 32 bit write is performed. If the
 * GPIO component is implemented in a smaller width, only the least
 * significant data is written.
 *
 * @param   BaseAddress is the base address of the GPIO device.
 * @param   RegOffset is the register offset from the base to write to.
 * @param   Data is the data written to the register.
 *
 * @return  None.
 *
 * @note    None.
 *
 ****************************************************************************/
#define XGpio_mWriteReg(BaseAddress, RegOffset, Data) \
    (XIo_Out32((BaseAddress) + (RegOffset), (Xuint32)(Data)))

/****************************************************************************/
/**
 *
 * Read a value from a GPIO register. A 32 bit read is performed. If the
 * GPIO component is implemented in a smaller width, only the least
 * significant data is read from the register. The most significant data
 * will be read as 0.
 *
 * @param   BaseAddress is the base address of the GPIO device.
 * @param   Register is the register offset from the base to write to.
 * @param   Data is the data written to the register.
 *
 * @return  None.
 *
 * @note    None.
 *
 ****************************************************************************/
#define XGpio_mReadReg(BaseAddress, RegOffset) \
    (XIo_In32((BaseAddress) + (RegOffset)))

/*****************************************************************************
*
* Set the input/output direction of all signals.
*
* @param    BaseAddress contains the base address of the GPIO device.
* @param    DirectionMask is a bitmask specifying which discretes are input and
*           which are output. Bits set to 0 are output and bits set to 1 are
*           input.
*
* @return   None.
*
* @note     None.
*
******************************************************************************/
#define XGpio_mSetDataDirection(BaseAddress, DirectionMask) \
    XGpio_mWriteReg((BaseAddress), XGPIO_TRI_OFFSET, (DirectionMask))


/****************************************************************************/
/**
* Get the data register.
*
* @param    BaseAddress contains the base address of the GPIO device.
*
* @return   The contents of the data register.
*
* @note     None.
*
*****************************************************************************/
#define XGpio_mGetDataReg(BaseAddress) \
    XGpio_mReadReg(BaseAddress, XGPIO_DATA_OFFSET)

/****************************************************************************/
/**
* Set the data register.
*
* @param    BaseAddress contains the base address of the GPIO device.
* @param    Data is the value to be written to the data register.
*
* @return   None.
*
* @note     None.
*
*****************************************************************************/
#define XGpio_mSetDataReg(BaseAddress, Data) \
    XGpio_mWriteReg((BaseAddress), XGPIO_DATA_OFFSET, (Data))


/************************** Function Prototypes ******************************/

/************************** Variable Definitions *****************************/

#endif            /* end of protection macro */

