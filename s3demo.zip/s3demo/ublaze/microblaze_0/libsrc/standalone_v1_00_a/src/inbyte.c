#include "xparameters.h"
#include "xuartlite_l.h"

char inbyte(void) {
	 XUartLite_RecvByte(STDIN_BASEADDRESS);
}
