/* $Id: xgpio_extra.c,v 1.5 2002/09/19 20:35:52 moleres Exp $ */
/******************************************************************************
*
*       XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
*       AS A COURTESY TO YOU, SOLELY FOR USE IN DEVELOPING PROGRAMS AND
*       SOLUTIONS FOR XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE,
*       OR INFORMATION AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE,
*       APPLICATION OR STANDARD, XILINX IS MAKING NO REPRESENTATION
*       THAT THIS IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
*       AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
*       FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
*       WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
*       IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
*       REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
*       INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
*       FOR A PARTICULAR PURPOSE.
*
*       (c) Copyright 2002 Xilinx Inc.
*       All rights reserved.
*
******************************************************************************/
/**
* @file xgpio_extra.c
*
* The implementation of the XGpio component's advanced discrete functions.
* See xgpio.h for more information about the component.
*
* @note
*
* None
*
*****************************************************************************/

/***************************** Include Files ********************************/
#include "xgpio.h"

/************************** Constant Definitions ****************************/

/**************************** Type Definitions ******************************/

/***************** Macros (Inline Functions) Definitions ********************/

/************************** Variable Definitions ****************************/

/************************** Function Prototypes *****************************/


/****************************************************************************/
/**
* Set output discrete(s) to logic 1.
* @param InstancePtr is a pointer to an XGpio instance to be worked on.
* @param Mask is the set of bits that will be set to 1 in the discrete data
*        register. All other bits in the data register are unaffected.
*
* @note
*
* None
*
*****************************************************************************/
void XGpio_DiscreteSet(XGpio *InstancePtr, Xuint32 Mask)
{
    Xuint32 Current;

    XASSERT_VOID(InstancePtr != XNULL);
    XASSERT_VOID(InstancePtr->IsReady == XCOMPONENT_IS_READY);

    /*
     * Read the contents of the data register, merge in Mask and write
     * back results
     */
    Current = XGpio_mReadReg(InstancePtr->BaseAddress, XGPIO_DATA_OFFSET);
    Current |= Mask;
    XGpio_mWriteReg(InstancePtr->BaseAddress, XGPIO_DATA_OFFSET, Current);
}


/****************************************************************************/
/**
* Set output discrete(s) to logic 0.
*
* @param InstancePtr is a pointer to an XGpio instance to be worked on.
* @param Mask is the set of bits that will be set to 0 in the discrete data
*        register. All other bits in the data register are unaffected.
*
* @note
*
* None
*
*****************************************************************************/
void XGpio_DiscreteClear(XGpio *InstancePtr, Xuint32 Mask)
{
    Xuint32 Current;

    XASSERT_VOID(InstancePtr != XNULL);
    XASSERT_VOID(InstancePtr->IsReady == XCOMPONENT_IS_READY);

    /*
     * Read the contents of the data register, merge in Mask and write
     * back results
     */
    Current = XGpio_mReadReg(InstancePtr->BaseAddress, XGPIO_DATA_OFFSET);
    Current &= ~Mask;
    XGpio_mWriteReg(InstancePtr->BaseAddress, XGPIO_DATA_OFFSET, Current);
}
