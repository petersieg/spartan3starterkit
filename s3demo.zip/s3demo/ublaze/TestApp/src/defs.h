#ifndef DDEBUG_H
#define DDEBUG_H

#define DDEBUG

#ifdef DDEBUG
#define DPRINT print
#else
#define DPRINT 
#endif

#endif
