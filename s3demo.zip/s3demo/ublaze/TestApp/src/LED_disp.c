/*-----------------------------------------------------------------------------
//
//     XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
//     SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
//     XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
//     AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
//     OR STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS
//     IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
//     AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
//     FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
//     WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
//     IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
//     REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
//     INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//     FOR A PARTICULAR PURPOSE.
//     
//     (c) Copyright 2003 Xilinx, Inc.
//     All rights reserved.
//
//---------------------------------------------------------------------------*/
#include "xparameters.h"
#include "xutil.h"
/* 
 * Driver for the 7-segment display controller - opb_7segled
 */

Xuint8 Digit[] =
   {
   0xC0,
   0xF9,
   0xA4,
   0xB0,
   0x99,
   0x92,
   0x82,
   0xF8,
   0x80,
   0x90
   };


#define  DLYVAL  28025

/*****************************************************************************
* Function name    :  dispLED( Xuint32 Val, Xuint8 DP )
* returns          :  Void
* Created by       :  SUS
* Date Created     :  06/21/2004
* Description      :  Writes a 4 digit value (VAL) to the 7-segment display and
*						places a decimal point at the disgit specifed by DP
* Input/Output     :  Val => 4 digit value to be printed to 7-segment display
*				   :  DP => Digit after decimal point is placed
*                  :  
*****************************************************************************/

void dispLED( Xuint32 Val, Xuint8 DP )
{
Xuint32 i;
Xuint8  *ledptr, dig;

   ledptr = (Xuint8 *)XPAR_LED_7SEGMENT_BASEADDR;

   for ( i=0; i<4; i++ )
      {
      dig = Digit[Val % 10];
	  if ( i == DP )
	     dig &= 0x7F;
      *(ledptr + i) = dig;
	  Val = Val / 10;
	  }
}
