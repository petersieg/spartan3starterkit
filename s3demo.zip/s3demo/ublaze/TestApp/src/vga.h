/*-----------------------------------------------------------------------------
//
//     XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
//     SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
//     XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
//     AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
//     OR STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS
//     IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
//     AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
//     FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
//     WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
//     IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
//     REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
//     INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//     FOR A PARTICULAR PURPOSE.
//     
//     (c) Copyright 2003 Xilinx, Inc.
//     All rights reserved.
//
//---------------------------------------------------------------------------*/
#ifndef _SCR_H
#define _SCR_H

#define CLR_R                     1
#define CLR_G                     2
#define CLR_B                     4

#define SCR_X_PIXELS              800
#define SCR_Y_PIXELS              600
#define SCR_X                     100
#define SCR_Y                     75

#define BLANK_CHAR                0
#define HORIZ_LINE_CHAR           128
#define VERT_LINE_CHAR            129
#define HORIZ_BARRED_LINE_CHAR    130
#define SOLID_SQUARE_CHAR         131

void scr_init ();
void scr_clr ();
void scr_clr_region (int sx, int sy, int ex, int ey);
void scr_write_char (int x, int y, char c, char color);
void scr_write_chars(int x, int y, char  color, char *buf, int count);
void scr_read_char  (int x, int y, char *c, char *color);
void scr_fill_char  (int x, int y, char c, char color, int count);
void scr_redefine_char (unsigned char c, unsigned int *defptr);
void scr_draw_horiz_line (int x, int y, char color, int linelen);
void scr_draw_vert_line (int x, int y, char color, int linelen);

#endif /* _SCR_H */
