/*-----------------------------------------------------------------------------
//
//     XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
//     SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
//     XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
//     AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
//     OR STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS
//     IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
//     AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
//     FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
//     WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
//     IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
//     REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
//     INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//     FOR A PARTICULAR PURPOSE.
//     
//     (c) Copyright 2003 Xilinx, Inc.
//     All rights reserved.
//
//---------------------------------------------------------------------------*/
#include "defs.h"
#include "xio.h"
#include "xparameters.h"
#include "vga.h"

/* 
 * Screen driver for the character-mode display controller - opb_color_video_ctrl
 * Please modify vga.h if you would like to change paramters of the video controller
 */

/* 
Character color mapping used by this driver
-------------------------------------------
'a' red
'b' green
'c' yellow
'd' blue
'e' magenta
'f' cyan
'g' white
'h' black
*/

#define SCR_BUF_BASEADDR          (XPAR_OPB_COLOR_VIDEO_CTRL_0_BASEADDR)
#define SCR_CTRL_REG_BASEADDR     (XPAR_OPB_COLOR_VIDEO_CTRL_0_BASEADDR + 0xA000)
#define SCR_CHAR_MAP_BASEADDR     (XPAR_OPB_COLOR_VIDEO_CTRL_0_BASEADDR + 0xC000)
#define xy2scroffset(x, y)        (((y * SCR_X) + x) << 2)
#define out32                     XIo_Out32 
#define pack_scr_char(c, clr)     ((((unsigned int)clr) << 8) | (c & 0xff))

static unsigned int null_char[8]  =         { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
static unsigned int solid_square_char[8]  = { 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff };
static unsigned int horiz_line[8] =         { 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
static unsigned int horiz_barred_line[8] =  { 0xff, 0xff, 0x03, 0x03, 0x03, 0x00, 0x00, 0x00 };
static unsigned int vert_line[8]  =         { 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18, 0x18 };


/*****************************************************************************
* Function name    :  scr_init(void) 
* returns          :  Void
* Created by       :  SUS
* Date Created     :  06/21/2004
* Description      :  Initialize a VGA controller
* Input/Output     :  None
*                  :  
*****************************************************************************/
void scr_init ()
{
    out32 (SCR_CTRL_REG_BASEADDR, 0x2);    // Enable the character mode in the control register of the videocontroller 
    scr_redefine_char (BLANK_CHAR,  null_char);
    scr_redefine_char (HORIZ_LINE_CHAR, horiz_line);
    scr_redefine_char (VERT_LINE_CHAR, vert_line);
    scr_redefine_char (HORIZ_BARRED_LINE_CHAR, horiz_barred_line);
    scr_redefine_char (SOLID_SQUARE_CHAR, solid_square_char);
}

/*****************************************************************************
* Function name    :  scr_clr(void) 
* returns          :  Void
* Created by       :  SUS
* Date Created     :  06/21/2004
* Description      :  Clears the VGA screen
* Input/Output     :  None
*                  :  
*****************************************************************************/
void scr_clr ()
{
    unsigned int *scr_buf_start = (unsigned int*)(SCR_BUF_BASEADDR);
    unsigned int *scr_buf_end   = (unsigned int*)(SCR_BUF_BASEADDR + xy2scroffset (SCR_X, SCR_Y));
    unsigned int *bufp;

    bufp = scr_buf_start;
    while (bufp <= scr_buf_end)
	*bufp++ = 0x0;

}

/*****************************************************************************
* Function name    :  scr_clr_region(int sx, int sy, int ex, int ey)
* returns          :  Void
* Created by       :  SUS
* Date Created     :  06/21/2004
* Description      :  Clears the VGA screen for a set region (rows) set by 
*						the X,Y parameters.
* Input/Output     :  int sx => starting X coordinate
*                  :  int sy => starting Y coordinate
*                  :  int ex => ending X coordinate
*                  :  int ey => ending Y coordinate
*                  :  
*****************************************************************************/
void scr_clr_region (int sx, int sy, int ex, int ey)
{
    unsigned int *scr_buf_start = (unsigned int*)(SCR_BUF_BASEADDR + xy2scroffset (sx, sy));
    unsigned int *scr_buf_end   = (unsigned int*)(SCR_BUF_BASEADDR + xy2scroffset (ex, ey));
    unsigned int *bufp;

    bufp = scr_buf_start;
    while (bufp <= scr_buf_end)
	*bufp++ = 0x0;

}

/*****************************************************************************
* Function name    :  scr_draw_horiz_line(int x, int y, char color, int linelen)
* returns          :  Void
* Created by       :  SUS
* Date Created     :  06/21/2004
* Description      :  Draws a horizontal line starting at the (x,y) coordinate 
*						in the color with a length of linelen
* Input/Output     :  x => starting X coordinate (0 to SCR_X)  
*                  :  y => starting Y coordinate (0 to SCR_Y)
*                  :  color => 'a' to g' (see top for color mapping to character)
*                  :  linelen => length of horzontal line
*                  :  
*****************************************************************************/
void scr_draw_horiz_line (int x, int y, char color, int linelen)
{
    int i;
    unsigned int  *basep = (unsigned int*)(SCR_BUF_BASEADDR + xy2scroffset (x,y));

    for (i=0; i<linelen; i++)
	XIo_Out32 (basep++, pack_scr_char (HORIZ_LINE_CHAR, color));
}

/*****************************************************************************
* Function name    :  scr_draw_vert_line(int x, int y, char color, int linelen) 
* returns          :  Void
* Created by       :  SUS
* Date Created     :  06/21/2004
* Description      :  Draws a vertical line starting at the (x,y) coordinate 
*						in the color with a length of linelen
* Input/Output     :  x => starting X coordinate (0 to SCR_X)  
*                  :  y => starting Y coordinate (0 to SCR_Y)
*                  :  color => 'a' to g' (see top for color mapping to character)
*                  :  linelen => length of vertical line
*                  :  
*****************************************************************************/
void scr_draw_vert_line (int x, int y, char color, int linelen)
{
    int i;
    unsigned int  *scrp = (unsigned int*)(SCR_BUF_BASEADDR + xy2scroffset (x,y));

    for (i=0; i<linelen; i++) {
	XIo_Out32 (scrp, pack_scr_char (VERT_LINE_CHAR, color));
	scrp = (unsigned int*)((unsigned int)scrp + (unsigned int)((unsigned int)SCR_X << 2));
    }
}

/*****************************************************************************
* Function name    :  scr_fill_char(int x, int y, char c, char color, int count)
* returns          :  Void
* Created by       :  SUS
* Date Created     :  06/21/2004
* Description      :  Fills a row with a character 'c' starting at (x,y) 
*						coordinate for count time
* Input/Output     :  x => starting X coordinate (0 to SCR_X)  
*                  :  y => starting Y coordinate (0 to SCR_Y)
*				   :  c => ASCII character displayed 'a'..'Z', '0'..'9'
*                  :  color => 'a' to g' (see top for color mapping to character)
*                  :  count => number of times character c is repeated
*                  :  
*****************************************************************************/
void scr_fill_char  (int x, int y, char c, char color, int count)
{
    int i;
    unsigned int  *basep = (unsigned int*)(SCR_BUF_BASEADDR + xy2scroffset (x,y));

    for (i=0; i<count; i++)
	XIo_Out32 (basep++, pack_scr_char (c, color));
}

/*****************************************************************************
* Function name    :  scr_write_chars(int x, int y, char color, char *buf, int count) 
* returns          :  Void
* Created by       :  SUS
* Date Created     :  06/21/2004
* Description      :  Writes a string (char* c) of characters for the number
* 						of chracters specified by count to the VGA port starting 
*						at the (x,y) coordinates
* Input/Output     :  x => starting X coordinate (0 to SCR_X)  
*                  :  y => starting Y coordinate (0 to SCR_Y)
*				   :  c => string of ASCII character displayed 'a'..'Z', '0'..'9'
*                  :  color => 'a' to g' (see top for color mapping to character)
*                  :  count => # characters in the string
*                  :  
*****************************************************************************/
void scr_write_chars  (int x, int y, char color, char *buf, int count)
{
    int i;
    unsigned int  *basep = (unsigned int*)(SCR_BUF_BASEADDR + xy2scroffset (x,y));

    for (i=0; i<count; i++)
	XIo_Out32 (basep++, pack_scr_char (*buf++, color));
}

/*****************************************************************************
* Function name    :  scr_write_chars(int x, int y, char c, char color)
* returns          :  Void
* Created by       :  SUS
* Date Created     :  06/21/2004
* Description      :  Writes a character to the VGA port starting 
*						at the (x,y) coordinates
* Input/Output     :  x => starting X coordinate (0 to SCR_X)  
*                  :  y => starting Y coordinate (0 to SCR_Y)
*				   :  c => ASCII character displayed 'a'..'Z', '0'..'9'
*                  :  color => 'a' to g' (see top for color mapping to character)
*                  :  
*****************************************************************************/

void scr_write_char (int x, int y, char c, char color)
{
    XIo_Out32((SCR_BUF_BASEADDR + xy2scroffset (x,y)), pack_scr_char (c, color));
}


void scr_redefine_char (unsigned char c, unsigned int *defptr)
{
    unsigned int *charp = (unsigned int*)(SCR_CHAR_MAP_BASEADDR + (unsigned int)(((unsigned int)c)<<5));

    *charp++ = *defptr++;
    *charp++ = *defptr++;
    *charp++ = *defptr++;
    *charp++ = *defptr++;
    *charp++ = *defptr++;
    *charp++ = *defptr++;
    *charp++ = *defptr++;
    *charp++ = *defptr++;
}