/*-----------------------------------------------------------------------------
//
//     XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
//     SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
//     XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
//     AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
//     OR STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS
//     IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
//     AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
//     FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
//     WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
//     IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
//     REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
//     INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//     FOR A PARTICULAR PURPOSE.
//     
//     (c) Copyright 2003 Xilinx, Inc.
//     All rights reserved.
//
//---------------------------------------------------------------------------*/

#include "xparameters.h"
#include <mb_interface.h>
#include "xutil.h"
#include "xgpio_l.h"
#define  DLYVAL  28025

/*
 * Routine to used as a "wait states" 
 */ 
void wait(int x) {
  int y;

  for (y = 0; y < x; y++);

}

/*
 * Routine to write a pattern out to a GPIO
 * which is configured as an output
 *   PARAMETER C_ALL_INPUTS = 0
 */ 
void WriteToGPOutput(Xuint32 BaseAddress, int gpio_width) {
   int i=0, j=0, k=0;
   int numTimes = 1;
 
   XGpio_mSetDataDirection(BaseAddress, 0x00000000);   /* Set as outputs */
   while (numTimes > 0) {
      j = 1;
      for(i=0; i<(gpio_width-1); i++) {
         XGpio_mSetDataReg(BaseAddress, j);
         j = j << 1;
         for (k=0; k<1000000; k++) {
            ; //wait
         }
      }
      j = 1;
      j = ~j;
      for(i=0; i<(gpio_width-1); i++) {
         XGpio_mSetDataReg(BaseAddress, j);
         j = j << 1;
         for (k=0; k<1000000; k++) {
            ; //wait
         }
      }
      numTimes--;
   }
}


/*
 * Routine to read data from a GPIO
 * which is configured as an input
 *   PARAMETER C_ALL_INPUTS = 1
 */
Xuint32 ReadFromGPInput(Xuint32 BaseAddress) {
   Xuint32 data = XGpio_mGetDataReg(BaseAddress);
   return data;
}

//====================================================

int main (void) {
unsigned int input, data;
int qwe;

print("-- Entering main() --\n\r");


//vga_test();
scr_init();

//draws a grid coordinate for the character map on the VGA port for a 800x600 screen
for(qwe=0;qwe<100;qwe++)
   {
   scr_write_char(qwe,2,'0'+(qwe%10),'b');
   if(qwe%10==0)
   	scr_write_char(qwe,1,'0'+(qwe/10),'b');
   if(qwe<73)
   	 	scr_write_char(2,qwe,'0'+(qwe%10),'a');	
		if(qwe%10==0)
   			scr_write_char(1,qwe,'0'+(qwe/10),'a');	
   }

// Writes "Spartan-3 Starter Kit Board!" to the VGA screen starting at
// row 10 column 10 and goes increase colum numbers as it changes colors
// to show all 8 colors
for(qwe=0;qwe<8;qwe++)
{
	scr_write_chars(10, (10+qwe), ('a'+qwe), "Spartan-3 Starter Kit Board!", 28);
}

//draws a horizontal line start at grid coordiate(x,y) 5,5 and spans for 15 characters
scr_draw_horiz_line (5, 5, 'd', 15);

//draws a vertical line start at grid coordiate(x,y) 8,8 and spans for 17 characters
scr_draw_vert_line (8, 8, 'e', 17);

// shows how to use the character fill driver displaying SPARTAN-3 15 times
// vertically with every letter in a different color starting at coordinate (20,20)
// color
// NOte the color 'h' is black and cannot be seen with a black background.
{
scr_fill_char  (20, 20, 'S', 'a', 15);
scr_fill_char  (21, 21, 'P', 'b', 15);
scr_fill_char  (22, 22, 'A', 'c', 15);
scr_fill_char  (23, 23, 'R', 'd', 15);
scr_fill_char  (24, 24, 'T', 'e', 15);
scr_fill_char  (25, 25, 'A', 'f', 15);
scr_fill_char  (26, 26, 'N', 'g', 15);
scr_fill_char  (27, 27, '-', 'h', 15);
scr_fill_char  (28, 28, '3', 'i', 15);

}

// Writes "Spartan-3 Starter Kit Board!" to the VGA screen starting at
// row 60 column 60 and goes increase colum numbers as it changes colors
// to show all 8 colors

for(qwe=0;qwe<8;qwe++)
{
	scr_write_chars(60, (60+qwe), ('a'+qwe), "Spartan-3 Starter Kit Board!", 28);
}
   
//reads button values and outputs the value to the UART
{
  Xuint32 dataA = ReadFromGPInput(XPAR_PUSH_BUTTONS_3BIT_BASEADDR);
  xil_printf("Data read from Push_Buttons_3Bit: 0x%x\n\r\n\r", dataA);
}

//reads the switch value and outputs values to the screen
{
  Xuint32 dataB = ReadFromGPInput(XPAR_DIP_SWITCHES_8BIT_BASEADDR);
  xil_printf("Data read from DIP_Switches_8Bit: 0x%x\n\r\n\r", dataB);
}


//testing RS232 input
// reads a number from the RS232 (UART) port and diplays it to the 7-segment display
print("-- Please enter any number to test the input of the RS232 --\n\r");
input = XUartLite_RecvByte(XPAR_RS232_BASEADDR);

//displays number read from RS232 port to the 7-segment display.  
//note that 48 is subtracted to conver the numebr from its ascii equivalent to 
//a decimal number      
   dispLED(input-48, 0);

print("The number entered in the RS232 port should be displayed on the 7-segment display.\n\r\n\r"); 
   
// testing PS/2 port
{
  print("-- Please enter any number or character on the PS/2 keyboard --\n\r");
  data = inbyte();
  dispLED(data, 0);
  xil_printf("pressed %c on ythe PS/2 Keyboard\n\r",data);	
}

print("-- Exiting main() --\n\r");
return 0;
}

