/*-----------------------------------------------------------------------------
//
//     XILINX IS PROVIDING THIS DESIGN, CODE, OR INFORMATION "AS IS"
//     SOLELY FOR USE IN DEVELOPING PROGRAMS AND SOLUTIONS FOR
//     XILINX DEVICES.  BY PROVIDING THIS DESIGN, CODE, OR INFORMATION
//     AS ONE POSSIBLE IMPLEMENTATION OF THIS FEATURE, APPLICATION
//     OR STANDARD, XILINX IS MAKING NO REPRESENTATION THAT THIS
//     IMPLEMENTATION IS FREE FROM ANY CLAIMS OF INFRINGEMENT,
//     AND YOU ARE RESPONSIBLE FOR OBTAINING ANY RIGHTS YOU MAY REQUIRE
//     FOR YOUR IMPLEMENTATION.  XILINX EXPRESSLY DISCLAIMS ANY
//     WARRANTY WHATSOEVER WITH RESPECT TO THE ADEQUACY OF THE
//     IMPLEMENTATION, INCLUDING BUT NOT LIMITED TO ANY WARRANTIES OR
//     REPRESENTATIONS THAT THIS IMPLEMENTATION IS FREE FROM CLAIMS OF
//     INFRINGEMENT, IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
//     FOR A PARTICULAR PURPOSE.
//     
//     (c) Copyright 2003 Xilinx, Inc.
//     All rights reserved.
//
//---------------------------------------------------------------------------*/
#include "xparameters.h"
#include "xutil.h"
#include "xgpio_l.h"
#include <mb_interface.h>

unsigned char getkey( unsigned int scancode ) ;
unsigned char inbyte() ;

#define microblaze_nbread_check(val) asm("mfs %0,rmsr" : "=d" (##val##))
unsigned int cur_scancode = 0;
unsigned int mark_scancode = 0 ;

/*****************************************************************************
* Function name    :  inbyte()
* returns          :  unsigned char
* Created by       :  SUS
* Date Created     :  06/21/2004
* Description      :  Returns a the ASCII equivalent to the keystroke read
*						from the keyboard sitting on FSL port 1
*                  :  
*****************************************************************************/
unsigned char inbyte()
{
	int break_scancode = 0, done = 0 ;
	unsigned int data  = 1 ;
	unsigned char ascii_input ;

	while(!done){ 		
	    microblaze_nbread_datafsl(data,1);
		if( !mark_scancode && (data != cur_scancode) ) {
			    mark_scancode = 1 ;
			    cur_scancode = data ;
	    }else if( mark_scancode && (data == 0xF0) ) {
		    break_scancode = 1 ;
	    }else if( break_scancode ) {
		    if( data == cur_scancode ) 
			    mark_scancode = 0 ;
		    else 
			    cur_scancode = data ;
		    ascii_input = getkey( cur_scancode ) ;
		    done = 1 ;
	    }
	}
	return ascii_input ;
}

/*****************************************************************************
* Function name    :  getkey( unsigned int scancode )
* returns          :  unsigned char
* Created by       :  SUS
* Date Created     :  06/21/2004
* Description      :  Returns the ASCII equivaent from the PS/2 scan code that 
*						was passed into the function.
* Input/Output     :  scancode => input of the PS/2 scancode
*                  :  
*****************************************************************************/
unsigned char getkey( unsigned int scancode )
{
	unsigned char ret ;
	switch( scancode ) {
	case 0x1c : ret = 'a' ; break ;
	case 0x32 : ret = 'b' ; break ;
	case 0x21 : ret = 'c' ; break ;
	case 0x23 : ret = 'd' ; break ;
	case 0x24 : ret = 'e' ; break ;
	case 0x2b : ret = 'f' ; break ;
	case 0x34 : ret = 'g' ; break ;
	case 0x33 : ret = 'h' ; break ;
	case 0x43 : ret = 'i' ; break ;
	case 0x3b : ret = 'j' ; break ;
	case 0x42 : ret = 'k' ; break ;
	case 0x4b : ret = 'l' ; break ;
	case 0x3a : ret = 'm' ; break ;
	case 0x31 : ret = 'n' ; break ;
	case 0x44 : ret = 'o' ; break ;
	case 0x4d : ret = 'p' ; break ;
	case 0x15 : ret = 'q' ; break ;
	case 0x2d : ret = 'r' ; break ;
	case 0x1b : ret = 's' ; break ;
	case 0x2c : ret = 't' ; break ;
	case 0x3c : ret = 'u' ; break ;
	case 0x2a : ret = 'v' ; break ;
	case 0x1d : ret = 'w' ; break ;
	case 0x22 : ret = 'x' ; break ;
	case 0x35 : ret = 'y' ; break ;
	case 0x1a : ret = 'z' ; break ;
	case 0x45 : ret = '0' ; break ;
	case 0x16 : ret = '1' ; break ;
	case 0x1e : ret = '2' ; break ;
	case 0x26 : ret = '3' ; break ;
	case 0x25 : ret = '4' ; break ;
	case 0x2e : ret = '5' ; break ;
	case 0x36 : ret = '6' ; break ;
	case 0x3d : ret = '7' ; break ;
	case 0x3e : ret = '8' ; break ;
	case 0x46 : ret = '9' ; break ;
	case 0x5a : ret = 0x0D ; break ; //Enter
	case 0x66 : ret = 0x08 ; break ; // Bksp
	case 0x29 : ret = 0x20 ; break ; // Space
		#if 0
	case 0x : ret = '' ; break ;
	case 0x : ret = '' ; break ;
	case 0x : ret = '' ; break ;
	case 0x : ret = '' ; break ;
	case 0x : ret = '' ; break ;
	case 0x : ret = '' ; break ;
	case 0x : ret = '' ; break ;
	case 0x : ret = '' ; break ;
		#endif
	default: ret = 0x0; break ;
	}
	return ret ;
}
