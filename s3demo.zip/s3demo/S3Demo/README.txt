Spartan 3 Digilent Demo:
	This demo drives the perphrials on the Spartan 3 board.  This drives a
simple pattern to the VGA port, connects the switches to the LEDs, buttons to
each anode of the seven segment decoder.  The seven segment decoder has a
simple counter running on it, and when SW0 is in the up position the seven 
segment decoder will display scan codes from the PS2 port.  This demo how ever
does not drive the RS-232 port or the memory.  This is a simple design done
entirely VHDL not microblaze.